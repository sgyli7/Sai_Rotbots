from pathlib import Path
import json,gzip
from cadgen import build123d as b
P=Path(__file__).resolve().parent;J=json.loads((P/'assembly_source.json').read_text());cache={};parts=[]
for r in J['parts']:
 s=r['native_source'];spec=s.get('input',s);path=P/spec['path'];key=spec['sha256']
 if key not in cache:
  if path.suffix=='.gz':
   tmp=P/'unpacked'/(key[:16]+'.brep');tmp.parent.mkdir(exist_ok=True);tmp.write_bytes(gzip.decompress(path.read_bytes()));path=tmp
  x=b.import_brep(path);cache[key]=(x,list(x.solids()))
 x,ss=cache[key]
 if 'input'in s:
  group=ss[s['solid_start']:s['solid_start']+s['solid_count']];x=group[0]if len(group)==1 else b.Compound(children=group)
 q=b.Compound(children=[x]);q.label=r['name'];parts.append(q)
b.export_brep(b.Compound(label='goose_complete_native_candidate',children=parts),P/'rebuilt_complete_native.brep')
print('COMPLETE_NATIVE_REBUILT',len(parts))
