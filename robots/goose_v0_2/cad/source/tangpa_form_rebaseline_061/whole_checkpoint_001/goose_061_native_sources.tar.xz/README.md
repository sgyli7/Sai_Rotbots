# Goose 061 complete native candidate

Open `goose_061_complete_native.brep` in an OpenCascade-compatible CAD application, or decompress the same `.brep.xz`. The named STEP exchange, when present, is separate and its readback limitations are listed in `export_receipt.json`.

`assembly_source.json` maps every occurrence to its included original native source, owner, finish role and qualification. All native sources are in `inputs/`. Rebuild with `uvx --managed-python --python 3.13 --from cadgen==0.7.21 python rebuild_complete_native.py`. This reproduces assembly geometry, not missing historical parameter trees.

This is a review candidate. Geometry health, finite motion gates, installation evidence, material assumptions and unresolved legacy source defects remain distinct. Do not migrate its mass or qualification to Frozen15.
