"""Source-supported local paired root return, preserving all other K mother faces.

The complete actual Al right-neck curve constrains both faces.  A local
supported 0.2mm lateral fit and 1.5mm lateral wall replace the unnecessary
4.7..10.9mm stand-off behind the old root budget; no broad root mask is
reintroduced. End geometry joins the existing front cap and actual M3 body.
"""
from pathlib import Path
import importlib.util,json,math,numpy as np
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('B',P/'build_named_shared_field_correction_031.py');B=importlib.util.module_from_spec(sp);sp.loader.exec_module(B);X=B.X;F=X.F;b=X.b;W=F.W
A=P/'complete_leg_shared_case_006/actual_required_inner_field_16/actual_fixed_interface_restore';bp=A/'body_protected_hidden_edges/positive_fit_02/candidate_metadata.json';base=json.loads(bp.read_text());O=A/'actual_supported_upper_root_pair';O.mkdir(exist_ok=True)
kmfolder=W/'artifacts/goose_v0_2/knee_loadpath_correction_020/candidate_006/revision_04';mp=kmfolder/'left_visible_structural_shin_primary_shell.brep';metal=b.import_brep(mp);y0=100.5;inner=[];outer=[]
# Every source face shares the true Y109.5 longitudinal boundary.  Its exact
# source edge is re-used, retaining the original smooth XZ neck contour.
for fi in range(74,86):
 face=metal.faces()[fi];edges=[e for e in face.edges()if max(abs(v.Y-109.5)for v in e.vertices())<1e-5]
 assert len(edges)==1,(fi,len(edges));e=edges[0]
 e=e if e.start_point().Z<e.end_point().Z else e.reversed()
 inner.append(e.moved(b.Location((.2,y0-109.5,0.))))
 outer.append(e.moved(b.Location((1.7,y0-109.5,0.))))
a=inner[0].start_point();z=inner[-1].end_point();oa=outer[0].start_point();oz=outer[-1].end_point()
wire=b.Wire(inner+[b.Edge.make_line(z,oz)]+[e.reversed()for e in outer[::-1]]+[b.Edge.make_line(oa,a)])
skin=b.Solid.extrude(b.Face(wire),(0.,176.31-y0,0.))
if F.props(skin)['volume_mm3']<0:skin=skin.reversed()
assert F.health(skin)==dict(strict=True,BOP=True,solids=1);b.export_brep(skin,O/'actual_paired_supported_neck_skin.brep')
J=dict(schema='061031_supported_upper_root_pair/1',builder=F.ref(Path(__file__)),base=F.ref(bp),source=F.ref(mp),source_faces=list(range(74,86)),paired_skin=F.ref(O/'actual_paired_supported_neck_skin.brep'),status='BUILDING_SAME_OWNER_ROOT_PAIR',parts=base['parts'][:2],checks=[],definition=dict(lateral_inner_offset_X_mm=.2,lateral_outer_offset_X_mm=1.7,projected_wall_X_mm=1.5,actual_normal_wall='Pending finite ray check; source normals nearly +X, lateral values are not labelled normal thickness',Y_mm=[y0,176.31],C45_face18='Actual closed structural face retained as the intentional exterior; no failed extra protective plate added',old_root_budget_not_applied=True))
def write():(O/'candidate_metadata.json').write_text(json.dumps(J,indent=2)+'\n')
write();parts=[b.import_brep(W/r['native']['path'])for r in base['parts']]
for i in [2,3]:
 add=X.keep(skin,X.box(-150.,125.15 if i==2 else 50.,0.,150.,200. if i==2 else 124.85,300.));merged=X.fuse(parts[i],add);name=['left_k_front_supported_upper_root_031','left_k_rear_supported_upper_root_031'][i-2];merged,r=F.save_native(merged,O/(name+'.brep'));r.update(name=name,body='left_knee_pitch',material='PA12',finish_role='theme_primary');J['parts'].append(r);parts[i]=merged;write();print('EVENT SUPPORTED_ROOT_SAVED',r,flush=True);assert r['health']==dict(strict=True,BOP=True,solids=1)
ka=b.Axis((F.K[0],125.,F.K[1]),(0,1,0));master=b.import_brep(W/'artifacts/goose_v0_2/enclosure_refinement_056/ankle/retained_hardware_input.brep');hpmetals=[master.solids()[i]for i in [1850,1852]]
def gate(label,s,t,**extra):
 h=X.keep(s,t);r=dict(relation=label,Common_solids=len(h.solids()),volume_mm3=F.props(h)['volume_mm3']if h.solids()else 0.,**extra)
 if h.solids():fn=O/('blocked_'+str(len(J['checks']))+'.brep');b.export_brep(h,fn);r['witness']=F.ref(fn)
 J['checks'].append(r);write();print('EVENT SUPPORTED_ROOT_GATE',r,flush=True)
for i in [2,3]:
 for mi,name in enumerate(['left_visible_structural_shin_primary_shell','left_visible_structural_shin_inner_C45_cover']):gate('actual_own_metal',parts[i],b.import_brep(kmfolder/(name+'.brep')),part=i,metal=mi)
 for q in [0.,-1.8]:
  s=parts[i].rotate(ka,math.degrees(q))
  for hi,h in enumerate(parts[:2]+hpmetals):gate('actual_HP_skin_or_true_metal',s,h,part=i,HP_input=hi,qK_rad=q)
J['status']='SUPPORTED_ROOT_SAVED_FINITE_CLEAR_INSTALL_APPEARANCE_OPEN'if not any(x['Common_solids']for x in J['checks'])else'REJECTED_TRUE_INTERFERENCE_KEEP_BODY02_BASE';write();print('EVENT SUPPORTED_ROOT_DONE',F.ref(O/'candidate_metadata.json'),flush=True)
