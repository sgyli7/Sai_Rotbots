"""Correct the old HP inner return that entered the true child neck.

One continuous source-derived root receiver, not individual posed witness
cuts. The existing outer b5 disk and all protected captures stay unchanged.
"""
from pathlib import Path
import importlib.util,json,math,numpy as np
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('B',P/'build_named_shared_field_correction_031.py');B=importlib.util.module_from_spec(sp);sp.loader.exec_module(B);X=B.X;F=X.F;H=X.H;b=X.b;W=F.W
A=P/'complete_leg_shared_case_006/actual_required_inner_field_16/actual_fixed_interface_restore';bp=A/'actual_supported_upper_root_pair/closed_C45_edge_termination/candidate_metadata.json';base=json.loads(bp.read_text());O=A/'actual_hidden_HP_child_receiver';O.mkdir(exist_ok=True)
mp=W/'artifacts/goose_v0_2/knee_loadpath_correction_020/candidate_006/revision_04/left_visible_structural_shin_primary_shell.brep';metal=b.import_brep(mp);ka=b.Axis((F.K[0],125.,F.K[1]),(0,1,0));y0=100.3;y1=176.51;qlo=-1.8;qhi=.2
# The upper angular envelope is the exact source right-neck outside curve,
# moved beyond the normal supported K skin and rotated to the maximum upper
# endpoint. Rotation about the same axis cannot exceed this angular endpoint.
edges=[]
for fi in range(74,86):
 es=[e for e in metal.faces()[fi].edges()if max(abs(v.Y-109.5)for v in e.vertices())<1e-5];assert len(es)==1;e=es[0];e=e if e.start_point().Z<e.end_point().Z else e.reversed();e=e.moved(b.Location((2.,y0-109.5,0.)));e=e.rotate(ka,math.degrees(qlo));edges.append(e)
a=edges[0].start_point();z=edges[-1].end_point();c=np.array(F.K);rhi=math.hypot(a.X-c[0],a.Z-c[1]);ri=37.;theta_a=math.degrees(math.atan2(a.Z-c[1],a.X-c[0]));theta_z=math.degrees(math.atan2(z.Z-c[1],z.X-c[0]))
def p(r,ang):return(float(c[0]+r*math.cos(math.radians(ang))),y0,float(c[1]+r*math.sin(math.radians(ang))))
innerhi=p(ri,70.);innerlo=p(ri,-180.);outerlo=p(rhi,-180.);transition=H.spline_edge(innerhi,p(39.5,68.),p(42.,theta_z+5.),tuple(z))
wire=b.Wire([transition]+[e.reversed()for e in edges[::-1]]+[b.Edge.make_three_point_arc(a,p(rhi,(theta_a-180.)/2),outerlo),b.Edge.make_line(outerlo,innerlo),b.Edge.make_three_point_arc(innerlo,p(ri,-55.),innerhi)])
tool=b.Solid.extrude(b.Face(wire),(0.,y1-y0,0.))
if F.props(tool)['volume_mm3']<0:tool=tool.reversed()
assert F.health(tool)==dict(strict=True,BOP=True,solids=1);b.export_brep(tool,O/'continuous_actual_child_neck_receiver.brep')
s=b.import_brep(W/base['parts'][0]['native']['path']);out=X.cut(s,tool);name='left_hp_front_actual_child_receiver_031';out,r=F.save_native(out,O/(name+'.brep'));r.update(name=name,body='left_hip_pitch',material='PA12',finish_role='theme_primary');assert r['health']==dict(strict=True,BOP=True,solids=1)
j=dict(base,parts=[r]+base['parts'][1:],builder=F.ref(Path(__file__)),source_selection=F.ref(bp),status='ACTUAL_HIDDEN_HP_RECEIVER_SAVED_LOCAL_GATES_PENDING',actual_receiver=F.ref(O/'continuous_actual_child_neck_receiver.brep'),receiver_definition=dict(actual_K_primary=F.ref(mp),actual_supported_wall_source=base['parts'][2]['native'],source_face_edges=list(range(74,86)),qK_rad=[qlo,qhi],inner_R_mm=ri,source_outer_curve_X_offset_mm=2.,Y_mm=[y0,y1],meaning='Same-axis continuous upper envelope at qK minimum; finite actual pair checks below do not automatically grant full ROM or coverage.'),checks=[])
def write():(O/'candidate_metadata.json').write_text(json.dumps(j,indent=2)+'\n')
write();print('EVENT HIDDEN_HP_RECEIVER_SAVED',r,flush=True)
b5p=P/'continuous_shallow_hp_pan_case_005/left_hp_front_axis_end_protection_031.brep';b5=b.import_brep(b5p);oldcap=X.keep(s,b5);missing=X.cut(oldcap,out);j['checks'].append(dict(relation='accepted_b5_outer_pan_retained',missing_solids=len(missing.solids())));write();assert not missing.solids()
for ki in [2,3]:
 k=b.import_brep(W/base['parts'][ki]['native']['path'])
 for q in [0.,-1.8]:
  hit=X.keep(out,k.rotate(ka,math.degrees(q)));row=dict(relation='corrected_HPfront_actual_K',K_part=ki,qK_rad=q,Common_solids=len(hit.solids()),volume_mm3=F.props(hit)['volume_mm3']if hit.solids()else 0.)
  if hit.solids():fn=O/('blocked_'+str(len(j['checks']))+'.brep');b.export_brep(hit,fn);row['witness']=F.ref(fn)
  j['checks'].append(row);write();print('EVENT HIDDEN_HP_RECEIVER_GATE',row,flush=True)
hit=X.keep(out,metal.rotate(ka,math.degrees(-1.8)));j['checks'].append(dict(relation='corrected_HPfront_original_Kprimary_minus1p8',Common_solids=len(hit.solids()),volume_mm3=F.props(hit)['volume_mm3']if hit.solids()else 0.));write()
j['status']='FINITE_PA_AND_TRUE_CHILD_CLEAR_FULL_SCOPE_OPEN'if not any(x.get('Common_solids',0)for x in j['checks'])else'REJECTED_REMAINING_ACTUAL_INTERFERENCE';write();print('EVENT HIDDEN_HP_RECEIVER_DONE',F.ref(O/'candidate_metadata.json'),flush=True)
