"""Retire only PA protected inside the actual closed body boundary.

Body028, visible hip mouth and all metal remain unchanged. The closure
keeps the true 028 recesses; 0.5mm is an axial fit budget, not normal gap.
"""
from pathlib import Path
import importlib.util,json,math,numpy as np
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('B',P/'build_named_shared_field_correction_031.py');B=importlib.util.module_from_spec(sp);sp.loader.exec_module(B);X=B.X;F=X.F;b=X.b;W=F.W
A=P/'complete_leg_shared_case_006/actual_required_inner_field_16/actual_fixed_interface_restore';bp=A/'single_ap_service_mouth/candidate_metadata.json';base=json.loads(bp.read_text());O=A/'body_protected_hidden_edges/positive_fit_02';O.mkdir(exist_ok=True)
source=W/'artifacts/goose_v0_2/enclosure_refinement_056/body/closed_belly_outer_selected.brep';q=b.import_brep(source)
for sign in [-1.,1.]:q=X.cut(q,b.Solid.make_sphere(1.).scale((60.25,20.25,45.25)).translate((-12.,sign*78.5,223.)))
q=X.cut(q,F.cy(49.5,-300.,300.,np.array([12.7560747091,330.6454814052])))
assert F.health(q)==dict(strict=True,BOP=True,solids=1);b.export_brep(q,O/'actual_body028_closed_protection_boundary.brep')
shifted=q.moved(b.Location((0.,.5,0.)));tool=X.fuse(q,shifted);b.export_brep(tool,O/'actual_body_closed_boundary_positive_axial_fit.brep')
J=dict(schema='061031_body_protected_hidden_edge_retirement/1',builder=F.ref(Path(__file__)),base=F.ref(bp),status='BUILDING_THREE_HIDDEN_PA_TERMINATIONS',parts=[],checks=[],definition=dict(body_native_unchanged=True,closed_body_outer=F.ref(source),true_028_recess_centres_mm=[[-12.,-78.5,223.],[-12.,78.5,223.]],true_028_recess_radii_mm=[60.45,20.45,45.45],PA_fit_recess_void_radii_mm=[60.25,20.25,45.25],original_hip_axis_XZ_mm=[12.7560747091,330.6454814052],original_hip_mouth_radius_mm=49.7,PA_protection_fit_void_radius_mm=49.5,recess_fit_shrink_each_axis_mm=.2,axis_fit_allowance_Y_mm=.5,meaning='Retire original PA termination material within the true closed body and its short positive-Y fit extension, preserving original recess and hip opening. Only the PA-side exclusion closure has 0.2 radial/pocket fit. Actual body and its R49.7 aperture remain unchanged. No bbox is a cutting operand; no body source change.',normal_motion_clearance='Measured below; axial budget is not a normal-distance claim.',closure_boundary=F.ref(O/'actual_body028_closed_protection_boundary.brep'),cutting_boundary=F.ref(O/'actual_body_closed_boundary_positive_axial_fit.brep')))
def write():(O/'candidate_metadata.json').write_text(json.dumps(J,indent=2)+'\n')
write();oldparts=[b.import_brep(W/r['native']['path'])for r in base['parts']];newparts=[]
for i,(r,s)in enumerate(zip(base['parts'],oldparts)):
 if i==2:newparts.append(s);J['parts'].append(r);continue
 out=X.cut(s,tool);name=['left_hp_front_body_protected_termination_031','left_hp_rear_body_protected_termination_031','','left_k_rear_body_protected_termination_031'][i];out,row=F.save_native(out,O/(name+'.brep'));row.update(name=name,body=r['body'],material='PA12',finish_role='theme_primary');J['parts'].append(row);newparts.append(out);write();assert row['health']==dict(strict=True,BOP=True,solids=1);print('EVENT BODY_PROTECTED_EDGE_SAVED '+str(row),flush=True)
 removed=X.cut(s,out);J['checks'].append(dict(relation='removed_original_PA_inside_actual_body_protection',part=i,removed_volume_mm3=F.props(removed)['volume_mm3']if removed.solids()else 0.,outside_tool_solids=len(X.cut(removed,tool).solids())));write()
bodyp=W/'artifacts/goose_v0_2/integrated_surface_cleanup_059/limbs/body_witness_feasibility_025/cost_probe_clearance_028/front_main_shell_local_closed_recess_clearance_028.brep';body=b.import_brep(bodyp)
for i in [0,1,3]:
 hit=X.keep(newparts[i],body);J['checks'].append(dict(relation='actual_body028_after_hidden_edge_retirement',part=i,body=F.ref(bodyp),Common_solids=len(hit.solids()),volume_mm3=F.props(hit)['volume_mm3']if hit.solids()else 0.,distance_mm=newparts[i].distance_to(body)));write();print('EVENT BODY_PROTECTED_EDGE_GATE '+str(J['checks'][-1]),flush=True)
# Functional features are checked by their original material, not by size.
for ci,c in enumerate([(-20.427129683,262.629632995),(7.588751666,264.994984904)]):
 old=X.keep(oldparts[1],F.cy(6.5,105.24,107.46,np.array(c)));missing=X.cut(old,newparts[1]);J['checks'].append(dict(relation='actual_HP_rear_M3_capture',capture=ci,old_volume_mm3=F.props(old)['volume_mm3']if old.solids()else 0.,missing_solids=len(missing.solids())));write();assert old.solids()and not missing.solids()
for ci,c in enumerate([(-17.5342220859,175.2860128193),(9.4339926658,144.9400531287)]):
 old=X.keep(oldparts[3],F.cy(6.5,100.49,102.71,np.array(c)));missing=X.cut(old,newparts[3]);J['checks'].append(dict(relation='actual_K_rear_M3_capture',capture=ci,old_volume_mm3=F.props(old)['volume_mm3']if old.solids()else 0.,missing_solids=len(missing.solids())));write();assert old.solids()and not missing.solids()
b5p=P/'continuous_shallow_hp_pan_case_005/left_hp_front_axis_end_protection_031.brep';b5=b.import_brep(b5p);old=X.keep(oldparts[0],b5);J['checks'].append(dict(relation='actual_b5_continuous_outer_pan_preserved',source=F.ref(b5p),missing_solids=len(X.cut(old,newparts[0]).solids())));write();assert not X.cut(old,newparts[0]).solids()
J['status']='BODY_SOURCE_UNCHANGED_HIDDEN_PA_EDGES_SAVED_FINITE_FIT_ONLY';write();print('EVENT BODY_PROTECTED_EDGE_COMPLETE '+str(F.ref(O/'candidate_metadata.json')),flush=True)
