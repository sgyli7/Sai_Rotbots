"""Seal the explicit rejected diagnostic with a true closed-C45 termination."""
from pathlib import Path
import importlib.util,json
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('B',P/'build_named_shared_field_correction_031.py');B=importlib.util.module_from_spec(sp);sp.loader.exec_module(B);X=B.X;F=X.F;b=X.b;W=F.W
A=P/'complete_leg_shared_case_006/actual_required_inner_field_16/actual_fixed_interface_restore';src=A/'actual_supported_upper_root_pair/candidate_metadata.json';j=json.loads(src.read_text());O=A/'actual_supported_upper_root_pair/closed_C45_edge_termination';O.mkdir(exist_ok=True)
old=b.import_brep(W/j['parts'][3]['native']['path']);mp=W/'artifacts/goose_v0_2/knee_loadpath_correction_020/candidate_006/revision_04/left_visible_structural_shin_inner_C45_cover.brep';metal=b.import_brep(mp)
# Actual closed source surface is the intended exposed boundary. This only
# removes PA that physically entered the metal, and does not retire its wire.
s=X.cut(old,metal);s,r=F.save_native(s,O/'left_k_rear_actual_closed_C45_termination_031.brep');r.update(name='left_k_rear_actual_closed_C45_termination_031',body='left_knee_pitch',material='PA12',finish_role='theme_primary');assert r['health']==dict(strict=True,BOP=True,solids=1)
hit=X.keep(s,metal);assert not hit.solids();base=json.loads((A/'body_protected_hidden_edges/positive_fit_02/candidate_metadata.json').read_text());oldbase=b.import_brep(W/base['parts'][3]['native']['path']);missing=X.cut(oldbase,s);assert not missing.solids()
j['parts'][3]=r;j.update(status='REJECTED_K_HP_MOTION_DIAGNOSTIC_ACTUAL_C45_TERMINATION',sealed_source=F.ref(src),builder=F.ref(Path(__file__)),C45_surface_role='Actual closed C45 native structural face and its true wire remain exposed as intentional product surface. No protective floating plate.',checks_not_requalified='Existing source checks remain bound to their original source; rear is an actual C45 subtraction subset. HPfront motion positives 204.8868/107.9298 remain rejection; no pass migration.')
j['checks'].append(dict(relation='new_rear_actual_C45_no_intersection',Common_solids=0,metal=F.ref(mp)))
j['checks'].append(dict(relation='all_original_body02_rear_material_retained',missing_solids=0,source=base['parts'][3]['native']))
(O/'candidate_metadata.json').write_text(json.dumps(j,indent=2)+'\n');print('EVENT ACTUAL_SOURCE_SEALED',F.ref(O/'candidate_metadata.json'),flush=True)
