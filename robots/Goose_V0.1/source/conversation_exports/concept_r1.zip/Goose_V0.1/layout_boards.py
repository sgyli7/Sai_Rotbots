"""Lay out original Goose concept renders. Requires Pillow and local CJK fonts."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
O=Path(__file__).parent
REG='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
BOLD='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
BG=(244,244,237); INK=(35,48,51); MUT=(93,103,103); ORANGE=(228,95,34); LINE=(207,213,203)
def ft(n,b=False):return ImageFont.truetype(BOLD if b else REG,n)
def text(d,xy,s,n=34,fill=INK,b=False):d.text(xy,s,font=ft(n,b),fill=fill)
def fit(im,path,box):
 src=Image.open(O/path).convert('RGB')
 # The thin first row is a renderer boundary artifact, not model geometry.
 src=src.crop((0,10,src.width,src.height))
 x,y,w,h=box;src.thumbnail((w,h),Image.Resampling.LANCZOS)
 im.paste(src,(round(x+(w-src.width)/2),round(y+(h-src.height)/2)))

def overview():
 im=Image.new('RGB',(2800,1900),BG);d=ImageDraw.Draw(im)
 text(d,(90,50),'GOOSE / V0.1',90,b=True)
 text(d,(96,174),'同一只鹅，三种移动方式',43)
 text(d,(2130,82),'SAI ROBOTS',40,b=True)
 text(d,(2128,139),'CONCEPT STUDY  01',29,fill=MUT)
 text(d,(2128,184),'27 SEP 2026',27,fill=MUT)
 d.line((90,258,2710,258),fill=LINE,width=3)
 cards=[('A','轮滑鹅','ROLLER GOOSE','双腿 × 四轮 / 动力轮滑','保留 MicroDuck 气质','双脚着地作业；抬脚仍需平衡','外形主线 · 优先深化'),
        ('B','步行鹅','WALKER GOOSE','双腿 × 宽脚掌 / 步态探索','更接近陆地行走的鹅','步态、抓取与重心需要协同','步态主线 · 控制难度最高'),
        ('C','轮式鹅','ROVER GOOSE','双驱动轮 + 后脚轮 / 三点支撑','先把叼取与搬运做扎实','室内验证底座，不等于会走路','验证主线 · 不追求仿生步态')]
 for i,(k,cn,en,sub,f1,f2,end) in enumerate(cards):
  x=90+i*888
  if i>0:d.line((x-22,313,x-22,1740),fill=LINE,width=2)
  text(d,(x+15,302),f'{k}  {cn}',55,b=True)
  text(d,(x+19,391),en,29,fill=MUT)
  text(d,(x+19,447),sub,30)
  fit(im,f'Goose_{k}_render.png',(x,501,844,1060))
  text(d,(x+20,1580),f1,37,b=True)
  text(d,(x+20,1644),f2,29,fill=MUT)
  text(d,(x+20,1700),end,30,fill=ORANGE if k=='A' else MUT,b=k=='A')
 d.line((90,1792,2710,1792),fill=LINE,width=2)
 text(d,(94,1821),'原创三维概念渲染，不是生产 CAD。电机选型、尺寸、负载与防摔能力尚未验收。',31,fill=MUT)
 im.save(O/'Goose_V0.1_Concept_Comparison.png',optimize=True)
 im.resize((1400,950),Image.Resampling.LANCZOS).save(O/'comparison_preview.jpg',quality=92)

def detail():
 im=Image.new('RGB',(2600,1840),BG);d=ImageDraw.Draw(im)
 text(d,(85,45),'A / ROLLER GOOSE',76,b=True)
 text(d,(90,159),'把机械臂变成脖子，把夹爪变成嘴。',42)
 text(d,(2010,82),'GOOSE_V0.1',34,b=True)
 text(d,(2010,141),'STRUCTURE + CHARACTER',24,fill=MUT)
 d.line((85,237,2515,237),fill=LINE,width=3)
 fit(im,'Goose_A_expression.png',(55,258,1220,1390))
 d.line((1300,284,1300,1645),fill=LINE,width=2)
 text(d,(1390,278),'头部 / 鹅颈结构研究',40,b=True)
 fit(im,'Goose_A_head_detail.png',(1360,342,1120,800))
 notes=[('01','鹅颈：7R 姿态链候选','转头、俯仰、歪头；并非增加一排铰链。'),
        ('02','嘴夹：橙色结构 + 可换软垫','薄边前缘用于探入，抓握面需单独试验。'),
        ('03','小腹：封闭机身，不设 Cargo','电池下置；侧盖承担检修功能，不加手臂。'),
        ('04','轮脚：动力 / 制动 / 模块更换','四轮为两只脚提供前后接地点，不承诺防摔。')]
 for i,(n,a,b) in enumerate(notes):
  y=1205+i*115
  text(d,(1384,y),n,32,fill=ORANGE,b=True)
  text(d,(1460,y-2),a,35,b=True)
  text(d,(1460,y+52),b,26,fill=MUT)
 text(d,(92,1665),'角色感来自姿态，而不是屏幕表情或多余肢体。',36,b=True)
 d.line((85,1740,2515,1740),fill=LINE,width=2)
 text(d,(90,1767),'关节为布置包络；尚未完成自碰撞、力矩、热负载、抓取与步行验证。',30,fill=MUT)
 im.save(O/'Goose_V0.1_A_Design_Study.png',optimize=True)
 im.resize((1300,920),Image.Resampling.LANCZOS).save(O/'detail_preview.jpg',quality=92)

if __name__=='__main__':overview();detail()
