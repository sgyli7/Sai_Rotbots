"""Goose V0.1: original, unvalidated concept geometry. Not manufacturing CAD.
Offline procedural rendering using VTK. SI-scale envelope only.
"""
import os, math, json
import numpy as np
import vtk
from vtk.util.numpy_support import numpy_to_vtk

OUT=os.path.dirname(__file__)
COL={
 'shell':(0.91,0.91,0.865), 'shell2':(.80,.82,.785),
 'dark':(.075,.095,.108),'rubber':(.095,.11,.12),'steel':(.46,.51,.53),
 'orange':(.96,.35,.065),'amber':(1,.59,.085),'face':(.23,.29,.30),
 'lens':(.025,.065,.085), 'glass':(.11,.27,.32), 'white':(.98,.98,.95),
 'floor':(.94,.94,.913)
}
class Model:
 def __init__(self): self.actors=[];self.parts=[]
 def add(self,pd,color,name,mat='plastic',T=None):
  if hasattr(pd,'GetOutputPort'):
   pd.Update(); poly=pd.GetOutput()
  else: poly=pd
  if T is not None:
   fl=vtk.vtkTransformPolyDataFilter();fl.SetInputData(poly);fl.SetTransform(T);fl.Update();poly=fl.GetOutput()
  normals=vtk.vtkPolyDataNormals();normals.SetInputData(poly);normals.SplittingOff();normals.ConsistencyOn();normals.Update()
  mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(normals.GetOutputPort())
  act=vtk.vtkActor();act.SetMapper(mapper)
  p=act.GetProperty();p.SetColor(COL.get(color,color));p.SetInterpolationToPhong();p.SetAmbient(.24);p.SetDiffuse(.70)
  p.SetSpecular(.25 if mat=='metal' else .13);p.SetSpecularPower(38 if mat=='metal' else 28)
  self.actors.append(act);self.parts.append((name,poly,COL.get(color,color)));return act
 def ell(self,c,d,col,name,exp=1):
  f=vtk.vtkParametricSuperEllipsoid();f.SetXRadius(d[0]/2);f.SetYRadius(d[1]/2);f.SetZRadius(d[2]/2);f.SetN1(exp);f.SetN2(exp)
  s=vtk.vtkParametricFunctionSource();s.SetParametricFunction(f);s.SetUResolution(64);s.SetVResolution(40)
  t=vtk.vtkTransform();t.Translate(*c);return self.add(s,col,name,T=t)
 def box(self,c,d,col,name,exp=.28):return self.ell(c,d,col,name,exp)
 def cyl(self,c,r,h,axis,col,name,metal=False):
  s=vtk.vtkCylinderSource();s.SetRadius(r);s.SetHeight(h);s.SetResolution(64);s.CappingOn()
  axis=np.asarray(axis,dtype=float);axis/=np.linalg.norm(axis)
  # VTK cylinder native axis is Y.
  y=np.array([0.,1.,0.]);cr=np.cross(y,axis);dt=np.dot(y,axis)
  t=vtk.vtkTransform();t.Translate(*c)
  if np.linalg.norm(cr)>1e-8:t.RotateWXYZ(math.degrees(math.acos(np.clip(dt,-1,1))),*cr)
  elif dt<0:t.RotateX(180)
  return self.add(s,col,name,'metal' if metal else 'plastic',T=t)
 def tube(self,pts,r,col,name):
  p=vtk.vtkPoints();[p.InsertNextPoint(*q) for q in pts]
  line=vtk.vtkPolyLine();line.GetPointIds().SetNumberOfIds(len(pts))
  for k in range(len(pts)):line.GetPointIds().SetId(k,k)
  cells=vtk.vtkCellArray();cells.InsertNextCell(line)
  pd=vtk.vtkPolyData();pd.SetPoints(p);pd.SetLines(cells)
  tub=vtk.vtkTubeFilter();tub.SetInputData(pd);tub.SetRadius(r);tub.SetNumberOfSides(24);tub.CappingOn()
  return self.add(tub,col,name)
 def bar(self,a,b,width,thick,col,name):
  a=np.array(a);b=np.array(b);v=b-a;l=np.linalg.norm(v)
  # rounded plate elongated along local Z; plane spans X/Z, normal Y
  f=vtk.vtkParametricSuperEllipsoid();f.SetXRadius(width/2);f.SetYRadius(thick/2);f.SetZRadius((l+width)/2);f.SetN1(.45);f.SetN2(.3)
  s=vtk.vtkParametricFunctionSource();s.SetParametricFunction(f);s.SetUResolution(48);s.SetVResolution(28)
  t=vtk.vtkTransform();t.Translate(*((a+b)/2));t.RotateY(math.degrees(math.atan2(v[0],v[2])))
  return self.add(s,col,name,T=t)
 def bolts(self,c,r,axis=(0,1,0),num=4,bolt=.0025):
  a=np.array(axis,dtype=float);a/=np.linalg.norm(a)
  u=np.cross(a,[0,0,1.])
  if np.linalg.norm(u)<.01:u=np.cross(a,[1.,0,0])
  u/=np.linalg.norm(u);v=np.cross(a,u)
  for k in range(num):
   th=k*math.tau/num+.3;pt=np.array(c)+r*(u*math.cos(th)+v*math.sin(th))
   self.cyl(pt,bolt,.0016,axis,'dark','fastener')
 def joint(self,c,r=.022,h=.046,axis=(0,1,0),accent=False):
  a=np.array(axis,dtype=float);a/=np.linalg.norm(a)
  self.cyl(c,r,h,axis,'dark','joint enclosure')
  for sg in [-1,1]:
   cc=np.array(c)+a*(h/2+.001)*sg
   self.cyl(cc,r*.9,.004,axis,'steel','bearing cover',True)
   self.cyl(cc+a*.0025*sg,r*.36,.002,axis,'orange' if accent else 'dark','output hub')
   self.bolts(cc+a*.003*sg,r*.63,axis,4,.00165)
 def wheel(self,c,r=.035,width=.025):
  self.cyl(c,r,width,(0,1,0),'rubber','rubber tyre')
  # thin tyre sidewall edge and hub on both sides
  for side in [-1,1]:
   cc=np.array(c)+np.array([0,side*(width/2+.0003),0])
   self.cyl(cc,r*.81,.0015,(0,1,0),'dark','tyre sidewall')
   self.cyl(cc+np.array([0,side*.001,0]),r*.61,.002,(0,1,0),'steel','wheel hub',True)
   self.cyl(cc+np.array([0,side*.0025,0]),r*.30,.003,(0,1,0),'orange','hub cap')
   self.bolts(cc+np.array([0,side*.003,0]),r*.42,(0,1,0),5,.0016)
  # fine circumferential ribs are tyre grooves, not extra wheels
  for yoff in [-width*.34,width*.34]:self.cyl(np.array(c)+[0,yoff,0],r*1.012,.001,(0,1,0),'dark','tread seam')

def goose(kind='A'):
 m=Model();dz=-.054 if kind=='C' else 0
 def P(x,y,z):return(x,y,z+dz)
 # One low, closed torso. Side panels are access covers, not extra limbs.
 m.box(P(-.035,0,.186),(.158,.137,.064),'dark','low battery enclosure',.42)
 m.ell(P(-.047,0,.222),(.202,.162,.113),'shell','closed torso',.55)
 m.ell(P(-.055,0,.184),(.170,.145,.048),'dark','belly bumper',.7)
 m.ell(P(-.139,0,.238),(.060,.078,.051),'shell','rear service cap',.6)
 for sy in [-1,1]:
  m.ell(P(-.048,sy*.079,.221),(.132,.012,.066),'shell2','access panel gasket',.6)
  m.ell(P(-.048,sy*.084,.223),(.124,.012,.059),'shell','battery service panel',.58)
  for bx in [-.092,-.010]:m.cyl(P(bx,sy*.091,.228),.0026,.001,(0,1,0),'steel','panel screw')
  # modest parallel vents near rear, actual apertures reserved for cooling
  for j in range(3):m.box(P(-.094+j*.01,sy*.091,.210),(.003,.002,.011),'dark','vent',.25)
 # No screen face. Single chest range-sensor window.
 m.box(P(.045,0,.217),(.006,.029,.018),'dark','chest range sensor',.3)
 m.box(P(.049,0,.217),(.001,.015,.008),'glass','range sensor window',.35)
 m.cyl(P(-.095,0,.271),.012,.014,(0,0,1),'dark','stop button pedestal')
 m.cyl(P(-.095,0,.278),.010,.007,(0,0,1),'orange','hardware stop button')
 # The proposed 7R neck. These are envelopes, not specified actuator internals.
 p0=np.array(P(.007,0,.273));p1=np.array(P(.008,0,.289));p2=np.array(P(-.025,0,.372));p3=np.array(P(.022,0,.431))
 m.cyl(p0,.031,.026,(0,0,1),'dark','J1 neck-base yaw')
 m.cyl(p0+[0,0,.014],.029,.004,(0,0,1),'orange','yaw collar')
 m.joint(p1,.024,.050,accent=True)
 # Split the fork around the axial joint; continuous plates would lock J3.
 d=(p2-p1);d/=np.linalg.norm(d)
 pm=p1*.52+p2*.48
 for sy in [-1,1]:
  yy=np.array([0,sy*.023,0])
  m.bar(p1+yy,pm-d*.022+yy,.019,.005,'shell','J3 fixed-side fork')
  m.bar(pm+d*.022+yy,p2+yy,.019,.005,'shell','J3 rotating-side fork')
  m.tube([pm-d*.020,pm-d*.020+yy],.006,'steel','twist fixed collar web')
  m.tube([pm+d*.020,pm+d*.020+yy],.006,'steel','twist rotating collar web')
 d=(p2-p1);d/=np.linalg.norm(d)
 pm=p1*.52+p2*.48
 m.cyl(pm,.019,.034,d,'dark','J3 neck axial twist')
 m.cyl(pm+d*.013,.020,.005,d,'steel','twist bearing',True)
 m.joint(p2,.021,.044,accent=False)
 for s in [-1,1]:m.bar(p2+[0,s*.025,0],p3+[0,s*.025,0],.022,.0045,'shell','upper-neck cheek plate')
 # visible harness loop outside bend; strain-relief concept only
 m.tube([P(-.008,.0,.280),P(-.040,.0,.306),P(-.050,0,.345),P(-.038,0,.379),P(-.004,0,.416)],.0033,'dark','neck cable service loop')
 m.cyl(p3,.020,.025,(0,0,1),'dark','J5 head yaw')
 m.cyl(p3+[0,0,.011],.021,.004,(0,0,1),'orange','head yaw collar')
 g=np.array(P(.042,0,.450))
 m.joint(g,.018,.050,accent=False)
 m.cyl(P(.059,0,.449),.019,.027,(1,0,0),'dark','J7 head roll')
 m.cyl(P(.071,0,.449),.021,.004,(1,0,0),'steel','roll bearing',True)
 # Head cap, one optical eye, mechanical beak with replaceable gripping pads.
 m.ell(P(.097,0,.476),(.111,.125,.086),'shell','light head cap',.47)
 m.box(P(.151,0,.475),(.008,.109,.065),'face','recessed sensor face',.54)
 m.cyl(P(.157,0,.480),.0235,.008,(1,0,0),'amber','camera ring')
 m.cyl(P(.162,0,.480),.0157,.004,(1,0,0),'dark','camera lens bezel')
 m.cyl(P(.165,0,.480),.0112,.002,(1,0,0),'lens','optical lens')
 m.ell(P(.167,-.003,.484),(.002,.005,.005),'glass','lens reflection')
 m.cyl(P(.157,.038,.463),.0033,.003,(1,0,0),'dark','microphone port')
 # upper jaw and lower jaw remain two visible parallel structures
 m.box(P(.161,0,.442),(.133,.128,.015),'orange','upper beak frame',.42)
 m.box(P(.169,0,.421),(.133,.119,.013),'orange','lower beak frame',.42)
 m.box(P(.194,0,.432),(.052,.095,.004),'dark','upper replaceable TPU pad',.3)
 m.box(P(.194,0,.429),(.052,.090,.004),'dark','lower replaceable TPU pad',.3)
 for s in [-1,1]:
  m.cyl(P(.109,s*.063,.433),.011,.008,(0,1,0),'orange','jaw hinge bracket')
  m.cyl(P(.109,s*.068,.433),.004,.002,(0,1,0),'steel','jaw hinge pin',True)
 m.box(P(.078,0,.429),(.035,.027,.028),'dark','jaw servo envelope')
 # Display small functional neck joints: no decorative feathers, arms, cargo tray.
 if kind in 'AB':
  for s in [-1,1]:
   y=s*.103
   h0=np.array((.002,s*.069,.178));h1=np.array((.002,y,.164));k=np.array((-.052,y,.112));a=np.array((.020,y,.068 if kind=='A' else .038))
   m.cyl(h0,.021,.028,(1,0,0),'dark','hip roll envelope')
   m.tube([h0,h1],.010,'steel','hip roll output bracket')
   m.joint(h1,.024,.041,accent=True)
   m.box((-.004,y,.174),(.043,.038,.032),'dark','hip servo enclosure')
   for f in [-1,1]:m.bar(h1+[0,f*.024,0],k+[0,f*.024,0],.028,.006,'shell','upper-leg plate')
   m.joint(k,.021,.048)
   for f in [-1,1]:m.bar(k+[0,f*.024,0],a+[0,f*.024,0],.024,.006,'steel','lower-leg plate')
   m.joint(a,.015,.050,accent=True)
   if kind=='A':
    yy=s*.111
    m.box((.024,yy,.061),(.184,.058,.028),'orange','powered skate housing',.32)
    m.box((.024,yy,.052),(.154,.040,.027),'dark','skate motor and belt envelope',.3)
    for x in [-.042,.090]:m.wheel((x,yy,.0345),.0345,.032)
    m.box((.024,yy,.078),(.061,.042,.012),'dark','ankle bracket')
    for xx in [-.037,.084]:m.cyl((xx,yy,.077),.0024,.0015,(0,0,1),'steel','foot screw')
   else:
    yy=s*.111
    m.box((.047,yy,.011),(.161,.087,.016),'rubber','replaceable walking sole',.43)
    m.box((.041,yy,.021),(.157,.082,.019),'orange','broad walking foot',.4)
    m.box((.011,yy,.034),(.047,.051,.021),'orange','ankle foot clevis',.4)
    for j in [-1,0,1]:m.box((.099,yy+j*.022,.031),(.035,.003,.0015),'dark','toe traction mark',.3)
 else:
  # C: precisely two main driven wheels and one rear caster, no hidden fourth wheel.
  for s in [-1,1]:
   yy=s*.112
   m.box((.006,yy,.101),(.049,.038,.080),'shell','short wheel fork',.42)
   m.joint((.015,yy,.139),.021,.042,accent=False)
   m.wheel((.029,yy,.067),.067,.037)
  m.bar((-.106,0,.102),(-.166,0,.032),.026,.026,'dark','rear caster support')
  m.cyl((-.167,0,.042),.012,.023,(0,0,1),'steel','caster swivel',True)
  m.wheel((-.175,0,.024),.024,.019)
 return m

def render(m,name,cam=(.95,-1.35,.72),target=(.015,0,.260),scale=.31,size=(1500,1700),ao=True):
 ren=vtk.vtkRenderer();ren.SetBackground(.957,.956,.931);ren.SetUseFXAA(True)
 for a in m.actors:ren.AddActor(a)
 # Floor and a low-amplitude contact shadow; SSAO supplies geometric contact shading.
 floor=vtk.vtkPlaneSource();floor.SetOrigin(-5,-5,.000);floor.SetPoint1(5,-5,.000);floor.SetPoint2(-5,5,.000)
 mp=vtk.vtkPolyDataMapper();mp.SetInputConnection(floor.GetOutputPort());act=vtk.vtkActor();act.SetMapper(mp)
 act.GetProperty().SetColor(.957,.956,.931);act.GetProperty().SetAmbient(1);act.GetProperty().SetDiffuse(0);ren.AddActor(act)
 ren.AutomaticLightCreationOff()
 for pos,power in [((-.2,-.8,1.7),.95),((.9,.4,1.2),.38),((-.8,.5,.9),.26)]:
  li=vtk.vtkLight();li.SetLightTypeToSceneLight();li.SetPosition(*pos);li.SetFocalPoint(0,0,.2);li.SetIntensity(power);ren.AddLight(li)
 camera=ren.GetActiveCamera();camera.SetPosition(*cam);camera.SetFocalPoint(*target);camera.SetViewUp(0,0,1);camera.ParallelProjectionOn();camera.SetParallelScale(scale)
 ren.ResetCameraClippingRange()
 if ao:
  basic=vtk.vtkRenderStepsPass();ssao=vtk.vtkSSAOPass();ssao.SetRadius(.038);ssao.SetBias(.0018);ssao.SetKernelSize(64);ssao.BlurOn();ssao.SetDelegatePass(basic);ren.SetPass(ssao)
 win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetMultiSamples(0);win.AddRenderer(ren);win.SetSize(*size);win.Render()
 flt=vtk.vtkWindowToImageFilter();flt.SetInput(win);flt.ReadFrontBufferOff();flt.Update()
 w=vtk.vtkPNGWriter();w.SetFileName(os.path.join(OUT,name));w.SetInputConnection(flt.GetOutputPort());w.Write();win.Finalize()
 print(name,flush=True)

def head_roll_pose(m,angle=-16):
 # Only the head / beak assembly rotates around the proposed J7 axis.
 start=next(i for i,part in enumerate(m.parts) if part[0]=='light head cap')
 end=next(i for i,part in enumerate(m.parts) if part[0]=='jaw servo envelope')
 pivot=(.071,0,.449)
 t=vtk.vtkTransform();t.Translate(*pivot);t.RotateX(angle);t.Translate(*(-np.array(pivot)))
 for a in m.actors[start:end+1]:a.SetUserTransform(t)
 return m

def export_vtp(m,name):
 # Original concept mesh only; no joint graph or dynamics claim.
 app=vtk.vtkAppendPolyData()
 for n,pd,col in m.parts:
  c=vtk.vtkPolyData();c.DeepCopy(pd)
  arr=np.tile(np.array(col)*255,(c.GetNumberOfPoints(),1)).astype('uint8')
  ca=numpy_to_vtk(arr,deep=True,array_type=vtk.VTK_UNSIGNED_CHAR);ca.SetName('RGB');c.GetPointData().SetScalars(ca);app.AddInputData(c)
 app.Update();w=vtk.vtkXMLPolyDataWriter();w.SetFileName(os.path.join(OUT,name));w.SetInputConnection(app.GetOutputPort());w.Write()

if __name__=='__main__':
 import sys
 which=sys.argv[1:] or ['A','B','C']
 for k in which:
  m=goose(k);render(m,f'Goose_{k}_render.png');export_vtp(m,f'Goose_{k}_concept.vtp')
 if 'A' in which:
  render(goose('A'),'Goose_A_side.png',cam=(0,-1.8,.260),target=(.015,0,.260),scale=.292,size=(1500,1550))
  render(head_roll_pose(goose('A')),'Goose_A_expression.png',scale=.31)
  render(goose('A'),'Goose_A_head_detail.png',cam=(1,-1.5,.65),target=(.082,0,.407),scale=.158,size=(1400,1120))
